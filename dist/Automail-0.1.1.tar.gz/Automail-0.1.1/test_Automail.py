from Automail import csv_list,send_email


def test_Automail_with_param():

	send_email()

	assert True